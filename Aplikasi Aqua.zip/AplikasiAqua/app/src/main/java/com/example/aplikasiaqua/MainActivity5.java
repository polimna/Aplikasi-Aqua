package com.example.aplikasiaqua;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

public class MainActivity5 extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private Button groupButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        drawerLayout = findViewById(R.id.drawer_layout);
        groupButton = findViewById(R.id.Tiga);

        groupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });

        // Update points when activity is created
        updatePoints();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Update points when activity is resumed
        updatePoints();
    }

    public void updatePoints() {
        TextView textViewPoints = findViewById(R.id.textViewPoints);
        int updatedPoints = User_Point.getUserPoints(this); // Pastikan UserPointsManager menangani poin pengguna
        textViewPoints.setText(String.valueOf(updatedPoints));
    }

    public void imageButton30(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity7.class);
        startActivity(intent);
    }

    public void imageButton10(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity7.class);
        startActivity(intent);
    }

    public void Reedem1(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity13.class);
        startActivity(intent);
    }

    public void imageButton11(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity14.class);
        startActivity(intent);
    }

    public void Royal1(View view) {
        Intent intent = new Intent(MainActivity5.this, MainActivity14.class);
        startActivity(intent);
    }
}
