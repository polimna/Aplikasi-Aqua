package com.example.aplikasiaqua;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity10 extends AppCompatActivity {

    private static final int REQUEST_CAMERA_PERMISSION = 1001;
    private static final int REQUEST_IMAGE_CAPTURE = 1002;
    private String lastScannedBarcode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main10);

        Button scanButton = findViewById(R.id.button10);
        scanButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkCameraPermission();
            }
        });
        TextView textViewPoints = findViewById(R.id.textViewPoints);
        int userPoints = User_Point.getUserPoints(this);
        textViewPoints.setText(String.valueOf(userPoints));
    }

    private void checkCameraPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            openCamera();
        }
    }

    private void openCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Set orientation to landscape
            takePictureIntent.putExtra(MediaStore.EXTRA_SCREEN_ORIENTATION, ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                openCamera();
            }
        }
    }

    private boolean checkIfBarcodeRegistered(String barcode) {
        // Cek apakah barcode sama dengan yang terakhir dipindai
        return barcode != null && !barcode.equals(lastScannedBarcode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ImageView scannedImageView = findViewById(R.id.scannedImage);
            scannedImageView.setImageBitmap(imageBitmap);

            // Mendapatkan barcode dari gambar (contoh: menggunakan proses OCR)
            String barcode = getBarcodeFromImage(imageBitmap);

            // Lakukan logika pengecekan barcode
            boolean isBarcodeRegistered = checkIfBarcodeRegistered(barcode);
            if (isBarcodeRegistered) {
                // Barcode baru, lanjutkan dengan tindakan yang sesuai
                lastScannedBarcode = barcode; // Simpan barcode terakhir
                Toast.makeText(this, "Barcode berhasil dipindai", Toast.LENGTH_SHORT).show();
            } else {
                // Barcode sudah dipindai sebelumnya
                Toast.makeText(this, "Barcode sudah dipindai sebelumnya", Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Metode sementara untuk mendapatkan barcode dari gambar
    private String getBarcodeFromImage(Bitmap imageBitmap) {
        // Implementasi sementara untuk mendapatkan barcode dari gambar (misalnya, menggunakan OCR)
        // Anda perlu mengganti ini dengan proses sesungguhnya untuk mendapatkan barcode dari gambar
        return "Barcode_Dummy_Value";
    }

    // Method ini untuk tombol "Scansuccess"
    public void scansuccess(View view) {
        // Lakukan apa yang perlu dilakukan saat pemindaian berhasil
        navigateToCongratulationsPage();
    }

    // Method ini untuk tombol "Cancelktp"
    public void cancelktp(View view) {
        // Lakukan apa yang perlu dilakukan saat pembatalan
        navigateToMainPage();
    }

    // Method ini untuk navigasi ke halaman "Congratulations"
    private void navigateToCongratulationsPage() {
        // Navigasi ke halaman "Congratulations"
        Intent intent = new Intent(this, MainActivity15.class);
        startActivity(intent);

        // Setelah 3 detik, kembali ke halaman utama
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                navigateToMainPage();
            }
        }, 3000);
    }

    // Method ini untuk navigasi ke halaman utama
    private void navigateToMainPage() {
        Intent intent = new Intent(this, MainActivity5.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        finish();
    }

    // Method untuk tombol "Imagebutton57"
    public void imageButton57(View view) {
        // Navigasi ke halaman utama
        Intent intent = new Intent(MainActivity10.this, MainActivity5.class);
        startActivity(intent);
    }

    // Method untuk tombol "Imagebutton59"
    public void imageButton59(View view) {
        // Navigasi ke halaman utama
        Intent intent = new Intent(MainActivity10.this, MainActivity5.class);
        startActivity(intent);
    }

    // Method untuk tombol "Imagebutton58"
    public void imageButton58(View view) {
        // Navigasi ke halaman "Congratulations"
        Intent intent = new Intent(MainActivity10.this, MainActivity15.class);
        startActivity(intent);
    }
}

