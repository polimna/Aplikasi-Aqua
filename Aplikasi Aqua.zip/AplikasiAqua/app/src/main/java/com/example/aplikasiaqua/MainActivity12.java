package com.example.aplikasiaqua;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity12 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main12);
    }

    public void Redeem(View view) {
        Intent intent = new Intent(MainActivity12.this, MainActivity14.class);
        startActivity(intent);
    }

    public void Vector1(View view) {
        Intent intent = new Intent(MainActivity12.this, MainActivity13.class);
        startActivity(intent);
    }
}